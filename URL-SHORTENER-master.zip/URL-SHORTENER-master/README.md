# URL-SHORTENER
Express,
Mongodb,
NodeJS,
ejs(for views) and shortid package for shortening URLS ![Preview](https://user-images.githubusercontent.com/122719642/232503172-b45496dc-f021-433a-a396-ac720e830714.png)

